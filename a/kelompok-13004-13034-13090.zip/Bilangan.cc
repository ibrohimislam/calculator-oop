#include "Bilangan.h"

EnumType Bilangan:: GetType() {
	return bil;
}