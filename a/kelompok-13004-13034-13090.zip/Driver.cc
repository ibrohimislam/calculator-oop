#include "Calculator.h"
int main()
{
	Calculator C;
	C.Run();
	return 0;
}